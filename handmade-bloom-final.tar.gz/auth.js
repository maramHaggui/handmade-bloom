const ADMIN_EMAIL = "admin@handmade.com";
const ADMIN_PASSWORD = "admin123";

function registerUser() {
  const name = document.getElementById("registerName").value.trim();
  const email = document.getElementById("registerEmail").value.trim();
  const password = document.getElementById("registerPassword").value.trim();
  const confirmPassword = document.getElementById("confirmPassword").value.trim();
  const message = document.getElementById("registerMessage");

  if (name === "" || email === "" || password === "" || confirmPassword === "") {
    showAuthMessage(message, "Veuillez remplir tous les champs.", "crimson");
    return;
  }

  if (password.length < 6) {
    showAuthMessage(message, "Le mot de passe doit contenir au moins 6 caractères.", "crimson");
    return;
  }

  if (password !== confirmPassword) {
    showAuthMessage(message, "Les mots de passe ne sont pas identiques.", "crimson");
    return;
  }

  let users = JSON.parse(localStorage.getItem("hb_users")) || [];

  const userExists = users.find(user => user.email === email);

  if (userExists) {
    showAuthMessage(message, "Cet email existe déjà.", "crimson");
    return;
  }

  const newUser = {
    id: Date.now(),
    name: name,
    email: email,
    password: password,
    role: "client"
  };

  users.push(newUser);
  localStorage.setItem("hb_users", JSON.stringify(users));

  showAuthMessage(message, "Compte créé avec succès 💖", "#ff7eb6");

  setTimeout(() => {
    window.location.href = "login.html";
  }, 1200);
}

function loginUser() {
  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value.trim();
  const message = document.getElementById("loginMessage");

  if (email === "" || password === "") {
    showAuthMessage(message, "Veuillez remplir tous les champs.", "crimson");
    return;
  }

  if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
    const admin = {
      id: 1,
      name: "Admin Handmade Bloom",
      email: ADMIN_EMAIL,
      role: "admin"
    };

    localStorage.setItem("hb_current_user", JSON.stringify(admin));
    window.location.href = "admin.html";
    return;
  }

  let users = JSON.parse(localStorage.getItem("hb_users")) || [];

  const foundUser = users.find(user => {
    return user.email === email && user.password === password;
  });

  if (!foundUser) {
    showAuthMessage(message, "Email ou mot de passe incorrect.", "crimson");
    return;
  }

  localStorage.setItem("hb_current_user", JSON.stringify(foundUser));

  showAuthMessage(message, "Connexion réussie 💖", "#ff7eb6");

  setTimeout(() => {
    window.location.href = "index.html";
  }, 1000);
}

function logoutUser() {
  localStorage.removeItem("hb_current_user");
  window.location.href = "login.html";
}

function protectAdminPage() {
  const currentUser = JSON.parse(localStorage.getItem("hb_current_user"));

  if (!currentUser || currentUser.role !== "admin") {
    window.location.href = "login.html";
  }
}

function showAuthMessage(element, message, color) {
  element.textContent = message;
  element.style.color = color;
}

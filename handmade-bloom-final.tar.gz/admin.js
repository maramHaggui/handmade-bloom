protectAdminPage();

const defaultProducts = [
  {
    id: 1,
    name: "Bijou handmade rose",
    price: 25,
    category: "bijoux",
    img: "image/b1.jpg",
    desc: "Bijou handmade élégant et girly."
  },
  {
    id: 2,
    name: "Bougie vanille fleurie",
    price: 32,
    category: "bougies",
    img: "image/c1.jpg",
    desc: "Bougie parfumée artisanale douce et girly."
  },
  {
    id: 3,
    name: "Pochette brodée",
    price: 45,
    category: "accessoires",
    img: "image/a1.jpg",
    desc: "Petite pochette handmade chic et pratique."
  }
];

let adminProducts =
  JSON.parse(localStorage.getItem("hb_admin_products")) || defaultProducts;

let orders = JSON.parse(localStorage.getItem("hb_orders")) || [];

function saveAdminProducts() {
  localStorage.setItem("hb_admin_products", JSON.stringify(adminProducts));
}

function renderAdminDashboard() {
  document.getElementById("totalProducts").textContent = adminProducts.length;
  document.getElementById("totalOrders").textContent = orders.length;

  const revenue = orders.reduce((sum, order) => {
    return sum + Number(order.total || 0);
  }, 0);

  document.getElementById("totalRevenue").textContent = revenue + " DT";

  renderAdminProducts();
  renderOrders();
}

function renderAdminProducts() {
  const table = document.getElementById("adminProductsTable");
  table.innerHTML = "";

  if (adminProducts.length === 0) {
    table.innerHTML = `
      <tr>
        <td colspan="5">Aucun produit disponible.</td>
      </tr>
    `;
    return;
  }

  adminProducts.forEach(product => {
    table.innerHTML += `
      <tr>
        <td>
          <img src="${product.img}" alt="${product.name}" class="admin-product-img" />
        </td>
        <td>${product.name}</td>
        <td>${product.category}</td>
        <td>${product.price} DT</td>
        <td>
          <button class="edit-admin-btn" onclick="editAdminProduct(${product.id})">
            Modifier
          </button>

          <button class="delete-admin-btn" onclick="deleteAdminProduct(${product.id})">
            Supprimer
          </button>
        </td>
      </tr>
    `;
  });
}

function saveAdminProduct() {
  const editId = document.getElementById("editProductId").value;
  const name = document.getElementById("productName").value.trim();
  const price = document.getElementById("productPrice").value.trim();
  const category = document.getElementById("productCategory").value;
  const img = document.getElementById("productImage").value.trim();
  const desc = document.getElementById("productDesc").value.trim();

  if (name === "" || price === "" || img === "" || desc === "") {
    alert("Veuillez remplir tous les champs.");
    return;
  }

  if (editId) {
    const product = adminProducts.find(item => item.id == editId);

    product.name = name;
    product.price = Number(price);
    product.category = category;
    product.img = img;
    product.desc = desc;

    document.getElementById("saveProductBtn").textContent = "Ajouter produit";
  } else {
    const newProduct = {
      id: Date.now(),
      name: name,
      price: Number(price),
      category: category,
      img: img,
      desc: desc
    };

    adminProducts.push(newProduct);
  }

  saveAdminProducts();
  renderAdminDashboard();
  resetProductForm();
}

function editAdminProduct(id) {
  const product = adminProducts.find(item => item.id === id);

  document.getElementById("editProductId").value = product.id;
  document.getElementById("productName").value = product.name;
  document.getElementById("productPrice").value = product.price;
  document.getElementById("productCategory").value = product.category;
  document.getElementById("productImage").value = product.img;
  document.getElementById("productDesc").value = product.desc;

  document.getElementById("saveProductBtn").textContent = "Modifier produit";
  window.location.href = "#productsAdmin";
}

function deleteAdminProduct(id) {
  adminProducts = adminProducts.filter(product => product.id !== id);

  saveAdminProducts();
  renderAdminDashboard();
}

function resetProductForm() {
  document.getElementById("editProductId").value = "";
  document.getElementById("productName").value = "";
  document.getElementById("productPrice").value = "";
  document.getElementById("productImage").value = "";
  document.getElementById("productDesc").value = "";
  document.getElementById("productCategory").value = "bijoux";
}

function renderOrders() {
  const ordersList = document.getElementById("ordersList");
  ordersList.innerHTML = "";

  if (orders.length === 0) {
    ordersList.innerHTML = `
      <p class="empty-admin-message">Aucune commande pour le moment.</p>
    `;
    return;
  }

  orders.forEach(order => {
    ordersList.innerHTML += `
      <div class="admin-order-card">
        <h3>Commande #${order.id}</h3>
        <p><strong>Client :</strong> ${order.client}</p>
        <p><strong>Téléphone :</strong> ${order.telephone}</p>
        <p><strong>Adresse :</strong> ${order.adresse}</p>
        <p><strong>Livraison :</strong> ${order.livraison}</p>
        <p><strong>Total :</strong> ${order.total} DT</p>
        <p><strong>Date :</strong> ${order.date}</p>
      </div>
    `;
  });
}

renderAdminDashboard();
